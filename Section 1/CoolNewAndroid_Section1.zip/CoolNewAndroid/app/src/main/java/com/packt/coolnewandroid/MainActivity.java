package com.packt.coolnewandroid;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    final public static int FORM_REQUEST_CODE = 1;
    final public static String KEY_AUTOMOBILE = "key_automobile";

    private ArrayList<String> automobiles = new ArrayList<>();

//    private ListView listView;
//    private AutomobileAdapter adapter;

    private RecyclerView recyclerView;
    private AutomobileRecyclerAdapter recyclerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//        listView = findViewById(R.id.list);
//        adapter = new AutomobileAdapter();
//        listView.setAdapter(adapter);

        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView recyclerView, @NonNull MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        Toast.makeText(MainActivity.this, "finger down", Toast.LENGTH_SHORT).show();
                    } break;

                    case MotionEvent.ACTION_UP: {
                        Toast.makeText(MainActivity.this, "finger up", Toast.LENGTH_SHORT).show();
                    } break;
                }
                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView recyclerView, @NonNull MotionEvent motionEvent) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean b) {

            }
        });
        recyclerAdapter = new AutomobileRecyclerAdapter();
        recyclerView.setAdapter(recyclerAdapter);

        if (savedInstanceState != null) {
            ArrayList<String> arrayList = savedInstanceState.getStringArrayList("auto");
            if (arrayList != null) {
                for (String s : arrayList) {
                    String [] strings = s.split(" ");
                    Automobile automobile = new Automobile(strings[0], strings[1]);
                    addAutoToList(automobile);
                }
            }
        }

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putStringArrayList("auto", automobiles);
        super.onSaveInstanceState(outState);
    }

    public void onClick(View view) {
        Intent intent = new Intent(MainActivity.this, FormActivity.class);
        startActivityForResult(intent, FORM_REQUEST_CODE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == FORM_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Automobile automobile = (Automobile) data.getSerializableExtra(KEY_AUTOMOBILE);
                addAutoToList(automobile);
            }
        }
    }


    private void addAutoToList(Automobile automobile) {
        automobiles.add(automobile.getMake() + " " + automobile.getModel());
//        adapter.addAutomobile(automobile);
        recyclerAdapter.addAutomobile(automobile);
    }
}
