package com.packt.coolnewandroid;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class AutomobileRecyclerAdapter extends RecyclerView.Adapter<AutomobileRecyclerAdapter.AutomobileViewHolder> {


    private List<Automobile> automobiles = new ArrayList<>();


    public void addAutomobile(Automobile automobile) {
        automobiles.add(automobile);
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public AutomobileViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(android.R.layout.simple_spinner_dropdown_item, viewGroup, false);
        return new AutomobileViewHolder((TextView)view);
    }

    @Override
    public void onBindViewHolder(@NonNull AutomobileViewHolder automobileViewHolder, int position) {
        Automobile automobile = automobiles.get(position);
        automobileViewHolder.name.setText(automobile.getMake() + " " + automobile.getModel());

    }

    @Override
    public int getItemCount() {
        return automobiles.size();
    }


    public static class AutomobileViewHolder extends RecyclerView.ViewHolder {

        private TextView name;

        public AutomobileViewHolder(@NonNull TextView itemView) {
            super(itemView);
            name = itemView;
        }

        public TextView getName() {
            return name;
        }
    }

}
